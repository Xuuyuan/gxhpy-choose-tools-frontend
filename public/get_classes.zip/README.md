# 个性化生成课表工具

## 使用方法

1. 在本目录下运行终端。
2. 安装 `requirements.txt` 中的全部依赖。
3. 在浏览器中正常访问[教务系统](https://jwglxt.fjnu.edu.cn/)，在选课界面点按F12打开 控制台 - 网络(Network) ，点击页面上的查询按钮。在接口信息处获取bh_id、xkkz_id、zyh_id。
    ![example](imgs/image.png)
4. 打开 `config.json` ，对其中的参数进行填充。

    ```json
    {
    "JWGLXT_USERNAME": "xxx", // 教务系统账号
    "JWGLXT_PASSWORD": "xxx", // 教务系统密码
    "NIANJI": "2023", // 所属年级
    "BH_ID": "xxx", // 班号，从教务系统抓包获取
    "xkkz_id": "xxx", // 选课控制ID，从教务系统抓包获取
    "kklxdm": "09", // 开课类型代码，无需修改，有修改需要则从教务系统抓包获取
    "zyh_id": "xxxx" // 专业号ID，从教务系统抓包获取
    }
    ```

5. 启动 `main.py` ，等待生成 `gxhpy_classes.json` 。
6. 访问 [个性化培养周选课工具](https://oss.nekoark.com/gxhpy/index.html)，点击右上角【上传JSON】按钮，上传生成的JSON文件。