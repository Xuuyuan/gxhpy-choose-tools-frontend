import base64
import binascii
import json
import re
import time
import traceback
import ddddocr
from pprint import pprint
import sys
import os
from urllib.parse import urljoin
import requests
import rsa
from pyquery import PyQuery as pq
from requests import exceptions

RASPIANIE = [
    ["8:00", "8:40"],
    ["8:45", "9:25"],
    ["9:30", "10:10"],
    ["10:30", "11:10"],
    ["11:15", "11:55"],
    ["14:30", "15:10"],
    ["15:15", "15:55"],
    ["16:05", "16:45"],
    ["16:50", "17:30"],
    ["18:40", "19:20"],
    ["19:25", "20:05"],
    ["20:10", "20:50"],
    ["20:55", "21:35"],
]


class Client:
    raspisanie = []
    ignore_type = []

    def __init__(self, cookies={}, **kwargs):
        # 基础配置
        self.base_url = kwargs.get("base_url")
        self.raspisanie = kwargs.get("raspisanie", RASPIANIE)
        self.ignore_type = kwargs.get("ignore_type", [])
        self.detail_category_type = kwargs.get("detail_category_type", [])
        self.timeout = kwargs.get("timeout", 3)
        Client.raspisanie = self.raspisanie
        Client.ignore_type = self.ignore_type

        self.key_url = urljoin(self.base_url, "xtgl/login_getPublicKey.html")
        self.login_url = urljoin(self.base_url, "xtgl/login_slogin.html")
        self.kaptcha_url = urljoin(self.base_url, "kaptcha")
        self.headers = requests.utils.default_headers()
        self.headers["Referer"] = self.login_url
        self.headers[
            "User-Agent"
        ] = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36"
        self.headers[
            "Accept"
        ] = "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3"
        self.sess = requests.Session()
        self.sess.keep_alive = False
        self.cookies = cookies

    def login(self, sid, password):
        """登录教务系统"""
        need_verify = False
        try:
            # 登录页
            req_csrf = self.sess.get(
                self.login_url, headers=self.headers, timeout=self.timeout
            )
            if req_csrf.status_code != 200:
                return {"code": 2333, "msg": "教务系统挂了"}
            # 获取csrf_token
            doc = pq(req_csrf.text)
            csrf_token = doc("#csrftoken").attr("value")
            pre_cookies = self.sess.cookies.get_dict()
            # 获取publicKey并加密密码
            req_pubkey = self.sess.get(
                self.key_url, headers=self.headers, timeout=self.timeout
            ).json()
            modulus = req_pubkey["modulus"]
            exponent = req_pubkey["exponent"]
            if str(doc("input#yzm")) == "":
                # 不需要验证码
                encrypt_password = self.encrypt_password(password, modulus, exponent)
                # 登录数据
                login_data = {
                    "csrftoken": csrf_token,
                    "yhm": sid,
                    "mm": encrypt_password,
                }
                # 请求登录
                req_login = self.sess.post(
                    self.login_url,
                    headers=self.headers,
                    data=login_data,
                    timeout=self.timeout,
                )
                doc = pq(req_login.text)
                tips = doc("p#tips")
                if str(tips) != "":
                    if "用户名或密码" in tips.text():
                        return {"code": 1002, "msg": "用户名或密码不正确"}
                    return {"code": 998, "msg": tips.text()}
                self.cookies = self.sess.cookies.get_dict()
                return {"code": 1000, "msg": "登录成功", "data": {"cookies": self.cookies}}
            # 需要验证码，返回相关页面验证信息给用户，TODO: 增加更多验证方式
            need_verify = True
            req_kaptcha = self.sess.get(
                self.kaptcha_url, headers=self.headers, timeout=self.timeout
            )
            kaptcha_pic = base64.b64encode(req_kaptcha.content).decode()
            return {
                "code": 1001,
                "msg": "获取验证码成功",
                "data": {
                    "sid": sid,
                    "csrf_token": csrf_token,
                    "cookies": pre_cookies,
                    "password": password,
                    "modulus": modulus,
                    "exponent": exponent,
                    "kaptcha_pic": kaptcha_pic,
                    "timestamp": time.time(),
                },
            }
        except exceptions.Timeout:
            msg = "获取验证码超时" if need_verify else "登录超时"
            return {"code": 1003, "msg": msg}
        except (
            exceptions.RequestException,
            json.decoder.JSONDecodeError,
            AttributeError,
        ):
            traceback.print_exc()
            return {"code": 2333, "msg": "请重试，若多次失败可能是系统错误维护或需更新接口"}
        except Exception as e:
            traceback.print_exc()
            msg = "获取验证码时未记录的错误" if need_verify else "登录时未记录的错误"
            return {"code": 999, "msg": f"{msg}：{str(e)}"}

    def login_with_kaptcha(
        self, sid, csrf_token, cookies, password, modulus, exponent, kaptcha, **kwargs
    ):
        """需要验证码的登陆"""
        try:
            encrypt_password = self.encrypt_password(password, modulus, exponent)
            login_data = {
                "csrftoken": csrf_token,
                "yhm": sid,
                "mm": encrypt_password,
                "yzm": kaptcha,
            }
            req_login = self.sess.post(
                self.login_url,
                headers=self.headers,
                cookies=cookies,
                data=login_data,
                timeout=self.timeout,
            )
            if req_login.status_code != 200:
                return {"code": 2333, "msg": "教务系统挂了"}
            # 请求登录
            doc = pq(req_login.text)
            tips = doc("p#tips")
            if str(tips) != "":
                if "验证码" in tips.text():
                    return {"code": 1004, "msg": "验证码输入错误"}
                if "用户名或密码" in tips.text():
                    return {"code": 1002, "msg": "用户名或密码不正确"}
                return {"code": 998, "msg": tips.text()}
            self.cookies = self.sess.cookies.get_dict()
            # 不同学校系统兼容差异
            if not self.cookies.get("route") and "route" in cookies:
                route_cookies = {
                    "JSESSIONID": self.cookies["JSESSIONID"],
                    "route": cookies["route"],
                }
                self.cookies = route_cookies
            else:
                return {"code": 1000, "msg": "登录成功", "data": {"cookies": self.cookies}}
        except exceptions.Timeout:
            return {"code": 1003, "msg": "登录超时"}
        except (
            exceptions.RequestException,
            json.decoder.JSONDecodeError,
            AttributeError,
        ):
            traceback.print_exc()
            return {"code": 2333, "msg": "请重试，若多次失败可能是系统错误维护或需更新接口"}
        except Exception as e:
            traceback.print_exc()
            return {"code": 999, "msg": "验证码登录时未记录的错误：" + str(e)}

    # ============= utils =================

    @classmethod
    def encrypt_password(cls, pwd, n, e):
        """对密码base64编码"""
        message = str(pwd).encode()
        rsa_n = binascii.b2a_hex(binascii.a2b_base64(n))
        rsa_e = binascii.b2a_hex(binascii.a2b_base64(e))
        key = rsa.PublicKey(int(rsa_n, 16), int(rsa_e, 16))
        encropy_pwd = rsa.encrypt(message, key)
        result = binascii.b2a_base64(encropy_pwd)
        return result

    @classmethod
    def display_course_time(cls, sessions):
        if not sessions:
            return None
        args = re.findall(r"(\d+)", sessions)
        start_time = cls.raspisanie[int(args[0]) + 1][0]
        end_time = cls.raspisanie[int(args[0]) + 1][1]
        return f"{start_time}~{end_time}"

    @classmethod
    def list_sessions(cls, sessions):
        if not sessions:
            return None
        args = re.findall(r"(\d+)", sessions)
        return [n for n in range(int(args[0]), int(args[1]) + 1)]
    
    def get_gexinghua_list(self, year: int, term: int = 0, xkkz_id: str = "", bh_id: str = "bh_id", njdm_id: str = "2023", zyh_id: str = "zyh_id", kklxdm: str = "09"):
        """获取个性化培养周课程信息"""
        url = urljoin(
            self.base_url,
            "xsxk/zzxkyzb_cxZzxkYzbPartDisplay.html?gnmkdm=N253512",
        )
        temp_term = term
        term = term**2 * 3
        term = "" if term == 0 else term
        data = {
            "xkxnm": str(year), # 学年数
            "xkxqm": str(term),  # 学期数
            "bh_id": bh_id,  # 班号ID
            "njdm_id": njdm_id,  # 年级代码
            "zyh_id": zyh_id,  # 专业号ID
            "kspage": "1", # 页码
            "xkkz_id": xkkz_id,
            "kklxdm": kklxdm,  # 开课类型代码
            "jspage": "10000",  # 查询的数量
            "rwlx": "2",
            "xklc": "1",
            "xqh_id": "2",
            "jg_id": kklxdm,
            "njdm_id_1": njdm_id,
            "zyh_id_1": zyh_id,
            "gnjkxdnj": "0",
            "zyfx_id": "wfx",
            "bjgkczxbbjwcx": "0",
            "xbm": "1",
            "xslbdm": "wlb",
            "mzm": "22",
            "xz": "4",
            "ccdm": "w",
            "njdm_id_xs": njdm_id,
            "zyh_id_xs": zyh_id
        }
        try:
            req_grade = self.sess.post(
                url,
                headers=self.headers,
                data=data,
                cookies=self.cookies,
                timeout=self.timeout,
            )
            if req_grade.status_code != 200:
                return {"code": 2333, "msg": "教务系统挂了"}
            doc = pq(req_grade.text)
            if doc("h5").text() == "用户登录":
                return {"code": 1006, "msg": "未登录或已过期，请重新登录"}
            grade = req_grade.json()
            grade_items = grade.get("tmpList")
            if not grade_items:
                return {"code": 1005, "msg": "获取内容为空"}
            result = {
                "year": year,
                "term": temp_term,
                "count": len(grade_items),
                "courses": [
                    {
                        "kcmc": i.get("kcmc"), # 课程名称
                        "yxzrs": i.get("yxzrs"), # 课程已选择人数
                        "kch_id": i.get("kch_id"), # 课程号ID
                        "jxb_id": i.get("jxb_id"), # 教学班ID
                    }
                    for i in grade_items
                ],
            }
            return {"code": 1000, "msg": "获取选课信息成功", "data": result}
        except exceptions.Timeout:
            return {"code": 1003, "msg": "获取选课信息超时"}
        except (
            exceptions.RequestException,
            json.decoder.JSONDecodeError,
            AttributeError,
        ):
            traceback.print_exc()
            return {"code": 2333, "msg": "请重试，若多次失败可能是系统错误维护或需更新接口"}
        except Exception as e:
            traceback.print_exc()
            return {"code": 999, "msg": "获取选课信息时未记录的错误：" + str(e)}

    def get_gexinghua_class_info(self, year: int, term: int = 0, kch_id: str = "", xkkz_id: str = "", kklxdm: str = "09", njdm_id: str = "2023", zyh_id: str = "zyh_id"):
        """获取个性化培养周课程信息"""
        url = urljoin(
            self.base_url,
            "xsxk/zzxkyzbjk_cxJxbWithKchZzxkYzb.html?gnmkdm=N253512",
        )
        temp_term = int(str(term))
        term = term**2 * 3
        term = "" if term == 0 else term
        data = {
            "xkxnm": str(year),  # 学年数
            "xkxqm": str(term),  # 学期数，第一学期为3，第二学期为12, 整个学年为空''
            "kch_id": kch_id,
            "xkkz_id": xkkz_id,
            "kklxdm": kklxdm,
            "xqh_id": str(temp_term),
            "zyh_id": zyh_id,
            "njdm_id": njdm_id,
            "njdm_id_xs": njdm_id,
            "zyh_id_xs": zyh_id,
        }
        try:
            req_grade = self.sess.post(
                url,
                headers=self.headers,
                data=data,
                cookies=self.cookies,
                timeout=self.timeout,
            )
            if req_grade.status_code != 200:
                return {"code": 2333, "msg": "教务系统挂了"}
            doc = pq(req_grade.text)
            if doc("h5").text() == "用户登录":
                return {"code": 1006, "msg": "未登录或已过期，请重新登录"}
            grade = req_grade.json()
            grade_items = grade
            if not grade_items:
                return {"code": 1005, "msg": "获取内容为空"}
            result = {
                "year": year,
                "term": temp_term,
                "count": len(grade_items),
                "courses": [
                    {
                        "kcmc": i.get("kcmc"), # 课程名称
                        "yxzrs": i.get("yxzrs"), # 课程已选择人数
                        "jxb_id": i.get("jxb_id"), # 教学班ID
                        "sksj": i.get("sksj"), # 上课时间
                        "kkxymc": i.get("kkxymc"), # 开课学院名称
                        "jxbrl": i.get("jxbrl"), # 教学班容量
                        "do_jxb_id": i.get("do_jxb_id"), # 选课ID
                        "jsxx": i.get("jsxx"), # 教师信息
                        "jxdd": i.get("jxdd"), # 上课地点
                    }
                    for i in grade_items
                ],
            }
            return {"code": 1000, "msg": "获取选课信息成功", "data": result}
        except exceptions.Timeout:
            return {"code": 1003, "msg": "获取选课信息超时"}
        except (
            exceptions.RequestException,
            json.decoder.JSONDecodeError,
            AttributeError,
        ):
            traceback.print_exc()
            return {"code": 2333, "msg": "请重试，若多次失败可能是系统错误维护或需更新接口"}
        except Exception as e:
            traceback.print_exc()
            return {"code": 999, "msg": "获取选课信息时未记录的错误：" + str(e)}

if __name__ == "__main__":
    with open(os.path.abspath("config.json"), mode="r", encoding="utf-8") as f:
        config = json.load(f)
    ocr = ddddocr.DdddOcr()
    # 参数配置
    base_url = "https://jwglxt.fjnu.edu.cn/jwglxt/"  # 教务系统URL
    sid = config.get("JWGLXT_USERNAME")  # 学号
    password = config.get("JWGLXT_PASSWORD")  # 密码
    bh_id = config.get("BH_ID")  # 班号ID，从选课接口获取
    njdm_id = config.get("NIANJI")  # 年级代码
    zyh_id = config.get("zyh_id")  # 专业号ID，从选课接口获取
    kklxdm = config.get("kklxdm")  # 开课类型代码，从选课接口获取
    xkkz_id = config.get("xkkz_id")
    
    lgn_cookies = ({"JSESSIONID": ""} if False else None)
    # lgn_cookies = {'JSESSIONID': 'xxx', 'Path': '/', 'SF_cookie_3': '17060112'}

    # 初始化
    lgn = Client(lgn_cookies if lgn_cookies is not None else {}, base_url=base_url)
    # 判断是否需要使用cookies登录
    if lgn_cookies is None:
        # 登录
        pre_login = lgn.login(sid, password)
        # 判断登录结果
        if pre_login["code"] == 1001:
            # 需要验证码
            pre_dict = pre_login["data"]
            with open(os.path.abspath("temp.json"), mode="w", encoding="utf-8") as f:
                f.write(json.dumps(pre_dict))
            image = base64.b64decode(pre_dict["kaptcha_pic"])
            kaptcha = ocr.classification(image)
            result = lgn.login_with_kaptcha(
                pre_dict["sid"],
                pre_dict["csrf_token"],
                pre_dict["cookies"],
                pre_dict["password"],
                pre_dict["modulus"],
                pre_dict["exponent"],
                kaptcha,
            )
            if result["code"] != 1000:
                pprint(result)
                sys.exit()
            lgn_cookies = lgn.cookies
        elif pre_login["code"] == 1000:
            # 不需要验证码，直接登录
            lgn_cookies = lgn.cookies
        else:
            # 出错
            pprint(pre_login)
            sys.exit()
    print(f"登录成功: {lgn_cookies}")
    
    # ————个性化部分————
    total_result = []
    for i in range(0, 10):
        result = lgn.get_gexinghua_list(2025, 1, xkkz_id, bh_id, njdm_id, zyh_id, kklxdm)
        if 'data' in result:
            break
    print(f"共取得 {result['data']['count']} 门课程")
    
    # =====构造json=====
    target_data = {}
    target_data['courses'] = []

    # 获取课程详细信息（报录人数）
    for i in result["data"]["courses"]:
        result_class = lgn.get_gexinghua_class_info(2025, 1, i['kch_id'], xkkz_id, kklxdm, njdm_id, zyh_id)
        if result_class["code"] != 1000:
            continue
        for j in result_class["data"]["courses"]:
            if i['jxb_id'] == j['jxb_id']:
                target_data['courses'].append({
                    "kcmc": i.get("kcmc"), # 课程名称
                    "yxzrs": i.get("yxzrs"), # 课程已选择人数
                    "jxb_id": i.get("jxb_id"), # 教学班ID
                    "sksj": j.get("sksj"), # 上课时间
                    "kkxymc": j.get("kkxymc"), # 开课学院名称
                    "jxbrl": j.get("jxbrl"), # 教学班容量
                    "yxrs": i.get("yxzrs"), # 课程已选人数
                    # "do_jxb_id": j.get("do_jxb_id"), # 选课ID
                    "jsxx": j.get("jsxx"), # 教师信息
                    "jxdd": j.get("jxdd"), # 上课地点
                })
                print("已处理课程 " + i.get("kcmc"))
    target_data['count'] = len(target_data['courses'])
    target_data['update_time'] = time.strftime("%Y年%m月%d日 %H:%M:%S", time.localtime())
    
    # 将target输出为gxhpy_classes.json
    with open(os.path.abspath("gxhpy_classes.json"), mode="w", encoding="utf-8") as f:
        f.write(json.dumps(target_data, ensure_ascii=False, indent=4))
    
    
